class Pessoa{//class pai

	constructor(nome, idade){
	
		this.nome = nome
		this.idade = idade
		
		
		}





}


module.exports = Pessoa