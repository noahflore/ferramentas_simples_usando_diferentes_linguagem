
class  Veiculo{
	
	constructor(marca,modelo,cor){
		
	
		this.marca = marca
		this.modelo = modelo
		this.cor = cor
		
	}
	
	
}

module.exports = Veiculo